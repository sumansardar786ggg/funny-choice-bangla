package com.example.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.rotate
import kotlin.random.Random

private data class ConfettiParticle(
    val xRatio: Float,
    val speedY: Float,
    val size: Float,
    val color: Color,
    val rotationSpeed: Float,
    val isCircle: Boolean
)

@Composable
fun ConfettiEffect(
    modifier: Modifier = Modifier,
    particleCount: Int = 40
) {
    val progress = remember { Animatable(0f) }

    LaunchedEffect(Unit) {
        progress.animateTo(
            targetValue = 1f,
            animationSpec = tween(durationMillis = 2000, easing = LinearEasing)
        )
    }

    val colors = listOf(
        Color(0xFFFFD166),
        Color(0xFF06D6A0),
        Color(0xFF118AB2),
        Color(0xFFEF476F),
        Color(0xFF9D4EDD),
        Color(0xFFFF924C)
    )

    val particles = remember {
        List(particleCount) {
            ConfettiParticle(
                xRatio = Random.nextFloat(),
                speedY = Random.nextFloat() * 0.8f + 0.6f,
                size = Random.nextFloat() * 16f + 12f,
                color = colors.random(),
                rotationSpeed = Random.nextFloat() * 720f - 360f,
                isCircle = Random.nextBoolean()
            )
        }
    }

    Canvas(modifier = modifier.fillMaxSize()) {
        val width = size.width
        val height = size.height
        val t = progress.value

        particles.forEach { p ->
            val x = p.xRatio * width + Math.sin((t * 10 + p.xRatio * 5).toDouble()).toFloat() * 30f
            val y = t * height * p.speedY - 50f
            val alpha = (1f - t).coerceIn(0f, 1f)
            val currentRotation = t * p.rotationSpeed

            if (y in 0f..height) {
                rotate(degrees = currentRotation, pivot = Offset(x, y)) {
                    if (p.isCircle) {
                        drawCircle(
                            color = p.color.copy(alpha = alpha),
                            radius = p.size / 2,
                            center = Offset(x, y)
                        )
                    } else {
                        drawRect(
                            color = p.color.copy(alpha = alpha),
                            topLeft = Offset(x - p.size / 2, y - p.size / 2),
                            size = Size(p.size, p.size * 0.7f)
                        )
                    }
                }
            }
        }
    }
}
