package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val VibrantBgDark = Color(0xFF0F0C29)
val VibrantBgMid = Color(0xFF24243E)
val VibrantBgTop = Color(0xFF302B63)

val VibrantIndigo = Color(0xFF6366F1)
val VibrantIndigoLight = Color(0xFF818CF8)
val VibrantIndigoGlow = Color(0x4D6366F1)

val VibrantYellow = Color(0xFFFACC15)
val VibrantOrange = Color(0xFFF97316)
val VibrantGreen = Color(0xFF4ADE80)
val VibrantRed = Color(0xFFEF4444)

val GlassWhite10 = Color(0x1AFFFFFF)
val GlassWhite05 = Color(0x0DFFFFFF)
val GlassWhite20 = Color(0x33FFFFFF)
val GlassBorder = Color(0x26FFFFFF)

val TextWhite = Color(0xFFFFFFFF)
val TextMuted = Color(0x99FFFFFF)
val TextIndigoLight = Color(0xFFA5B4FC)

// Aliases for compatibility
val NeonPurple = VibrantIndigo
val NeonPurpleDark = VibrantBgTop
val CyanGlow = VibrantGreen
val GoldenYellow = VibrantYellow
val DarkBackground = VibrantBgDark
val SurfacePurple = GlassWhite10
val SurfacePurpleLight = GlassWhite20
val CorrectGreen = VibrantGreen
val WrongRed = VibrantRed


