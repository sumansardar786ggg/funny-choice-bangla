package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val VibrantPaletteColorScheme = darkColorScheme(
    primary = VibrantIndigo,
    onPrimary = Color.White,
    secondary = VibrantGreen,
    onSecondary = Color.Black,
    tertiary = VibrantYellow,
    background = VibrantBgDark,
    onBackground = TextWhite,
    surface = GlassWhite10,
    onSurface = TextWhite,
    surfaceVariant = GlassWhite20,
    onSurfaceVariant = TextWhite,
    error = VibrantRed,
    onError = Color.White
)

@Composable
fun MyApplicationTheme(
    content: @Composable () -> Unit,
) {
    MaterialTheme(
        colorScheme = VibrantPaletteColorScheme,
        typography = Typography,
        content = content
    )
}

