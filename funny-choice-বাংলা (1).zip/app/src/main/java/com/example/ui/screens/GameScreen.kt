package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.GameState
import com.example.model.Question
import com.example.ui.components.ConfettiEffect
import com.example.ui.components.shake
import com.example.ui.theme.GlassBorder
import com.example.ui.theme.GlassWhite05
import com.example.ui.theme.GlassWhite10
import com.example.ui.theme.GlassWhite20
import com.example.ui.theme.TextIndigoLight
import com.example.ui.theme.TextWhite
import com.example.ui.theme.VibrantBgDark
import com.example.ui.theme.VibrantBgMid
import com.example.ui.theme.VibrantBgTop
import com.example.ui.theme.VibrantGreen
import com.example.ui.theme.VibrantIndigo
import com.example.ui.theme.VibrantIndigoGlow
import com.example.ui.theme.VibrantIndigoLight
import com.example.ui.theme.VibrantOrange
import com.example.ui.theme.VibrantRed
import com.example.ui.theme.VibrantYellow

@Composable
fun GameScreen(
    gameState: GameState,
    currentQuestion: Question,
    totalLevels: Int,
    onSelectOption: (Int) -> Unit,
    onNextQuestion: () -> Unit,
    onToggleSound: () -> Unit,
    modifier: Modifier = Modifier
) {
    val backgroundBrush = Brush.verticalGradient(
        colors = listOf(
            VibrantBgTop.copy(alpha = 0.3f),
            VibrantBgMid.copy(alpha = 0.6f),
            VibrantBgDark
        )
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(VibrantBgDark)
            .background(backgroundBrush)
            .padding(16.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Header stats bar (Vibrant Palette style)
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Level Badge
                    Column {
                        Text(
                            text = "লেভেল",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextIndigoLight,
                            letterSpacing = 1.sp
                        )
                        Text(
                            text = "${(gameState.currentLevelIndex + 1).toString().padStart(2, '০')} / $totalLevels",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Black,
                            color = VibrantYellow
                        )
                    }

                    // Lives Bar Badge
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(20.dp))
                            .background(GlassWhite10)
                            .border(1.dp, GlassBorder, RoundedCornerShape(20.dp))
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            for (i in 1..3) {
                                val isAlive = i <= gameState.lives
                                Icon(
                                    imageVector = if (isAlive) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                                    contentDescription = "Life $i",
                                    tint = if (isAlive) VibrantRed else TextWhite.copy(alpha = 0.3f),
                                    modifier = Modifier
                                        .padding(horizontal = 2.dp)
                                        .size(20.dp)
                                )
                            }
                        }
                    }

                    // Score Display
                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = "স্কোর",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextIndigoLight,
                            letterSpacing = 1.sp
                        )
                        Text(
                            text = "${gameState.score}",
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Black,
                            color = VibrantGreen
                        )
                    }

                    // Sound Toggle Button
                    IconButton(
                        onClick = onToggleSound,
                        modifier = Modifier
                            .testTag("game_sound_toggle")
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(GlassWhite10)
                            .border(1.dp, GlassBorder, CircleShape)
                    ) {
                        Icon(
                            imageVector = if (gameState.isSoundEnabled) Icons.Default.VolumeUp else Icons.Default.VolumeOff,
                            contentDescription = "Sound Toggle",
                            tint = if (gameState.isSoundEnabled) VibrantYellow else TextWhite.copy(alpha = 0.4f),
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Progress Bar
                LinearProgressIndicator(
                    progress = { (gameState.currentLevelIndex + 1).toFloat() / totalLevels.toFloat() },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(6.dp)
                        .clip(RoundedCornerShape(3.dp)),
                    color = VibrantIndigo,
                    trackColor = GlassWhite10
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Question Card with Vibrant Glass styling
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .shake(gameState.isAnswerChecked && !gameState.isAnswerCorrect),
                shape = RoundedCornerShape(28.dp),
                colors = CardDefaults.cardColors(
                    containerColor = GlassWhite10
                ),
                border = androidx.compose.foundation.BorderStroke(
                    2.dp,
                    if (gameState.isAnswerChecked) {
                        if (gameState.isAnswerCorrect) VibrantGreen else VibrantRed
                    } else VibrantIndigoGlow
                ),
                elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Top handle bar accent
                    Box(
                        modifier = Modifier
                            .width(48.dp)
                            .height(5.dp)
                            .clip(RoundedCornerShape(3.dp))
                            .background(VibrantIndigo.copy(alpha = 0.5f))
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        text = currentQuestion.questionText,
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontSize = 21.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextWhite,
                            lineHeight = 30.sp
                        ),
                        textAlign = TextAlign.Center
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Options List with Vibrant Glass Buttons
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                currentQuestion.options.forEachIndexed { index, optionText ->
                    val isSelected = gameState.selectedOptionIndex == index
                    val isCorrectOption = index == currentQuestion.correctOptionIndex

                    val borderColor = when {
                        !gameState.isAnswerChecked -> if (isSelected) VibrantIndigoLight else GlassBorder
                        isCorrectOption -> VibrantGreen
                        isSelected && !gameState.isAnswerCorrect -> VibrantRed
                        else -> Color.Transparent
                    }

                    val containerColor = when {
                        !gameState.isAnswerChecked -> if (isSelected) GlassWhite20 else GlassWhite05
                        isCorrectOption -> VibrantGreen.copy(alpha = 0.25f)
                        isSelected && !gameState.isAnswerCorrect -> VibrantRed.copy(alpha = 0.25f)
                        else -> GlassWhite05.copy(alpha = 0.5f)
                    }

                    Card(
                        modifier = Modifier
                            .testTag("option_$index")
                            .fillMaxWidth()
                            .clickable(enabled = !gameState.isAnswerChecked) {
                                onSelectOption(index)
                            },
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = containerColor),
                        border = androidx.compose.foundation.BorderStroke(
                            if (isSelected || (gameState.isAnswerChecked && isCorrectOption)) 2.dp else 1.dp,
                            borderColor
                        )
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 18.dp, vertical = 16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = optionText,
                                style = MaterialTheme.typography.bodyLarge.copy(
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = TextWhite
                                ),
                                modifier = Modifier.weight(1f)
                            )

                            Spacer(modifier = Modifier.width(12.dp))

                            Box(
                                modifier = Modifier
                                    .size(26.dp)
                                    .clip(CircleShape)
                                    .background(
                                        when {
                                            gameState.isAnswerChecked && isCorrectOption -> VibrantGreen
                                            gameState.isAnswerChecked && isSelected && !gameState.isAnswerCorrect -> VibrantRed
                                            isSelected -> VibrantIndigo
                                            else -> Color.Transparent
                                        }
                                    )
                                    .border(
                                        2.dp,
                                        when {
                                            gameState.isAnswerChecked && isCorrectOption -> VibrantGreen
                                            gameState.isAnswerChecked && isSelected && !gameState.isAnswerCorrect -> VibrantRed
                                            isSelected -> VibrantIndigo
                                            else -> TextWhite.copy(alpha = 0.3f)
                                        },
                                        CircleShape
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                if (gameState.isAnswerChecked) {
                                    Text(
                                        text = if (isCorrectOption) "✓" else if (isSelected) "✕" else "",
                                        color = Color.White,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Reaction Banner Bar
            AnimatedVisibility(
                visible = gameState.isAnswerChecked,
                enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
                exit = slideOutVertically(targetOffsetY = { it }) + fadeOut()
            ) {
                val bannerBg = if (gameState.isAnswerCorrect) VibrantGreen else VibrantRed

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = bannerBg
                    ),
                    elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = if (gameState.isAnswerCorrect) "🎉" else "💀",
                            fontSize = 32.sp,
                            modifier = Modifier.padding(end = 12.dp)
                        )

                        Column(
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(
                                text = if (gameState.isAnswerCorrect) "অসাধারণ উত্তর!" else "আরে ভাই, এটা কী করলে! 😂",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Text(
                                text = gameState.currentReaction,
                                fontSize = 12.sp,
                                color = Color.White.copy(alpha = 0.9f),
                                lineHeight = 16.sp
                            )
                        }

                        Spacer(modifier = Modifier.width(10.dp))

                        Button(
                            onClick = onNextQuestion,
                            modifier = Modifier
                                .testTag("next_question_button"),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color.White,
                                contentColor = if (gameState.isAnswerCorrect) Color(0xFF047857) else Color(0xFFDC2626)
                            )
                        ) {
                            Text(
                                text = if (gameState.lives <= 0) "ফলাফল" else "পরবর্তী",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        // Trigger Confetti Effect on Correct Answer
        if (gameState.isAnswerChecked && gameState.isAnswerCorrect) {
            ConfettiEffect()
        }
    }
}

