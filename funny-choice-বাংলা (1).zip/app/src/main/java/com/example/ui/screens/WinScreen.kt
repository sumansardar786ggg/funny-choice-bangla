package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.GameState
import com.example.ui.components.ConfettiEffect
import com.example.ui.theme.GlassBorder
import com.example.ui.theme.GlassWhite10
import com.example.ui.theme.TextIndigoLight
import com.example.ui.theme.TextWhite
import com.example.ui.theme.VibrantBgDark
import com.example.ui.theme.VibrantBgMid
import com.example.ui.theme.VibrantBgTop
import com.example.ui.theme.VibrantGreen
import com.example.ui.theme.VibrantIndigo
import com.example.ui.theme.VibrantYellow

@Composable
fun WinScreen(
    gameState: GameState,
    totalLevels: Int,
    onRestartGame: () -> Unit,
    onGoToHome: () -> Unit,
    modifier: Modifier = Modifier
) {
    val backgroundBrush = Brush.verticalGradient(
        colors = listOf(
            VibrantBgTop.copy(alpha = 0.4f),
            VibrantBgMid.copy(alpha = 0.6f),
            VibrantBgDark
        )
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(VibrantBgDark)
            .background(backgroundBrush)
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        // Continuous Celebration Confetti on Win Screen!
        ConfettiEffect(particleCount = 60)

        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // Trophy Badge
            Box(
                modifier = Modifier
                    .size(115.dp)
                    .clip(CircleShape)
                    .background(VibrantYellow.copy(alpha = 0.2f))
                    .border(3.dp, VibrantYellow, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "🏆",
                    fontSize = 60.sp
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            Text(
                text = "অভিনন্দন! তুমি জিতে গেছো! 🏆",
                style = MaterialTheme.typography.headlineMedium.copy(
                    fontWeight = FontWeight.Black,
                    fontSize = 28.sp,
                    color = VibrantYellow
                ),
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "তুমি সফলতা সহকারে ২০টি লেভেল সম্পন্ন করেছো!",
                style = MaterialTheme.typography.bodyLarge.copy(
                    color = TextWhite,
                    fontSize = 15.sp
                ),
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(24.dp))

            // Score Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(28.dp),
                colors = CardDefaults.cardColors(containerColor = GlassWhite10),
                border = androidx.compose.foundation.BorderStroke(2.dp, VibrantYellow)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(22.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "চূড়ান্ত স্কোর",
                        fontSize = 13.sp,
                        color = TextIndigoLight,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = "${gameState.score}",
                        fontSize = 46.sp,
                        fontWeight = FontWeight.Black,
                        color = VibrantGreen
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = VibrantYellow.copy(alpha = 0.2f),
                        border = androidx.compose.foundation.BorderStroke(1.dp, VibrantYellow)
                    ) {
                        Text(
                            text = "আদর্শ উত্তরদাতা 👑",
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                            color = VibrantYellow,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Text(
                        text = "“অসাধারণ বুদ্ধি তোমার! তুমি সত্যিই বাংলার সেরা ফানি চয়েস চ্যাম্পিয়ন!” 🧠🔥",
                        fontSize = 15.sp,
                        color = VibrantYellow,
                        textAlign = TextAlign.Center,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(32.dp))

            // Play Again Button
            Button(
                onClick = onRestartGame,
                modifier = Modifier
                    .testTag("win_restart_button")
                    .fillMaxWidth()
                    .height(56.dp),
                shape = RoundedCornerShape(28.dp),
                colors = ButtonDefaults.buttonColors(containerColor = VibrantIndigo)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.PlayArrow,
                        contentDescription = null,
                        tint = Color.White
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "আবার খেলো 🎮",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            OutlinedButton(
                onClick = onGoToHome,
                modifier = Modifier
                    .testTag("win_home_button")
                    .fillMaxWidth()
                    .height(52.dp),
                shape = RoundedCornerShape(26.dp),
                border = androidx.compose.foundation.BorderStroke(1.5.dp, GlassBorder)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Home,
                        contentDescription = null,
                        tint = TextIndigoLight
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "হোম স্ক্রিন 🏠",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextIndigoLight
                    )
                }
            }
        }
    }
}

