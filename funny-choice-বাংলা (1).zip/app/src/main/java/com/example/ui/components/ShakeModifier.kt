package com.example.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.spring
import androidx.compose.foundation.layout.offset
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

fun Modifier.shake(trigger: Boolean): Modifier = composed {
    val offsetX = remember { Animatable(0f) }

    LaunchedEffect(trigger) {
        if (trigger) {
            val shakePositions = listOf(-24f, 24f, -16f, 16f, -8f, 8f, 0f)
            for (pos in shakePositions) {
                offsetX.animateTo(
                    targetValue = pos,
                    animationSpec = spring(stiffness = 1000f)
                )
            }
        }
    }

    this.offset(x = offsetX.value.dp)
}
