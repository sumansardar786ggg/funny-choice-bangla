package com.example.ui.screens

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.GameState
import com.example.ui.theme.GlassBorder
import com.example.ui.theme.GlassWhite05
import com.example.ui.theme.GlassWhite10
import com.example.ui.theme.TextIndigoLight
import com.example.ui.theme.TextWhite
import com.example.ui.theme.VibrantBgDark
import com.example.ui.theme.VibrantBgMid
import com.example.ui.theme.VibrantBgTop
import com.example.ui.theme.VibrantGreen
import com.example.ui.theme.VibrantIndigo
import com.example.ui.theme.VibrantIndigoGlow
import com.example.ui.theme.VibrantOrange
import com.example.ui.theme.VibrantYellow

@Composable
fun HomeScreen(
    gameState: GameState,
    onStartGame: () -> Unit,
    onToggleSound: () -> Unit,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val scalePulse by infiniteTransition.animateFloat(
        initialValue = 0.96f,
        targetValue = 1.04f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "scalePulse"
    )

    val backgroundBrush = Brush.verticalGradient(
        colors = listOf(
            VibrantBgTop.copy(alpha = 0.4f),
            VibrantBgMid.copy(alpha = 0.6f),
            VibrantBgDark
        )
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(VibrantBgDark)
            .background(backgroundBrush)
            .padding(20.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Sound Toggle Top Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onToggleSound,
                    modifier = Modifier
                        .testTag("home_sound_toggle")
                        .size(42.dp)
                        .clip(CircleShape)
                        .background(GlassWhite10)
                        .border(1.dp, GlassBorder, CircleShape)
                ) {
                    Icon(
                        imageVector = if (gameState.isSoundEnabled) Icons.Default.VolumeUp else Icons.Default.VolumeOff,
                        contentDescription = "Sound Toggle",
                        tint = if (gameState.isSoundEnabled) VibrantYellow else TextWhite.copy(alpha = 0.4f)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Main Branding Section
            Column(
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Animated Emoji Badge
                Box(
                    modifier = Modifier
                        .scale(scalePulse)
                        .size(115.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.radialGradient(
                                colors = listOf(VibrantIndigo, VibrantBgTop)
                            )
                        )
                        .border(3.dp, VibrantYellow, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "🤣",
                        fontSize = 58.sp
                    )
                }

                Spacer(modifier = Modifier.height(20.dp))

                Text(
                    text = "Funny Choice বাংলা 😂",
                    style = MaterialTheme.typography.headlineLarge.copy(
                        fontWeight = FontWeight.Black,
                        fontSize = 32.sp,
                        color = Color.White
                    ),
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "তুমি কতটা চালাক? দেখি! 😎",
                    style = MaterialTheme.typography.titleMedium.copy(
                        color = VibrantYellow,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    ),
                    textAlign = TextAlign.Center
                )

                if (gameState.highScore > 0) {
                    Spacer(modifier = Modifier.height(14.dp))
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = GlassWhite10,
                        border = androidx.compose.foundation.BorderStroke(1.dp, VibrantYellow)
                    ) {
                        Text(
                            text = "সর্বোচ্চ স্কোর: ${gameState.highScore} 🏆",
                            modifier = Modifier.padding(horizontal = 18.dp, vertical = 7.dp),
                            color = VibrantYellow,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Instructions Card (Vibrant Glassmorphism)
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 4.dp),
                shape = RoundedCornerShape(28.dp),
                colors = CardDefaults.cardColors(
                    containerColor = GlassWhite10
                ),
                border = androidx.compose.foundation.BorderStroke(1.5.dp, VibrantIndigoGlow)
            ) {
                Column(
                    modifier = Modifier.padding(22.dp)
                ) {
                    Text(
                        text = "কীভাবে খেলবে? 📖",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = VibrantYellow,
                            fontSize = 19.sp
                        )
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "• মোট ২০টি অত্যন্ত মজার প্রশ্ন থাকবে\n• প্রতিটি প্রশ্নের ৩–৪টি উত্তর থেকে বেছে নাও\n• সঠিক উত্তর দিলে +১০ পয়েন্ট পাবে 🎯\n• ভুল হলে ১টি লাইফ কমবে ❤️\n• ৩টি লাইফ শেষ হওয়ার আগেই জয়ী হও!",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            color = TextWhite,
                            fontSize = 14.sp,
                            lineHeight = 22.sp
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(28.dp))

            // Start Game Button
            Button(
                onClick = onStartGame,
                modifier = Modifier
                    .testTag("start_game_button")
                    .fillMaxWidth()
                    .height(64.dp)
                    .scale(scalePulse),
                shape = RoundedCornerShape(32.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = VibrantIndigo
                ),
                elevation = ButtonDefaults.buttonElevation(defaultElevation = 10.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.PlayArrow,
                        contentDescription = null,
                        modifier = Modifier.size(32.dp),
                        tint = Color.White
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "খেলা শুরু করো 🎮",
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))
        }
    }
}

