package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.GameState
import com.example.ui.theme.GlassBorder
import com.example.ui.theme.GlassWhite10
import com.example.ui.theme.GlassWhite20
import com.example.ui.theme.TextIndigoLight
import com.example.ui.theme.TextWhite
import com.example.ui.theme.VibrantBgDark
import com.example.ui.theme.VibrantBgMid
import com.example.ui.theme.VibrantBgTop
import com.example.ui.theme.VibrantGreen
import com.example.ui.theme.VibrantIndigo
import com.example.ui.theme.VibrantRed
import com.example.ui.theme.VibrantYellow

@Composable
fun GameOverScreen(
    gameState: GameState,
    totalLevels: Int,
    onRestartGame: () -> Unit,
    onGoToHome: () -> Unit,
    modifier: Modifier = Modifier
) {
    val backgroundBrush = Brush.verticalGradient(
        colors = listOf(
            VibrantBgTop.copy(alpha = 0.4f),
            VibrantBgMid.copy(alpha = 0.6f),
            VibrantBgDark
        )
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(VibrantBgDark)
            .background(backgroundBrush)
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // Crying Skull Emoji Circle
            Box(
                modifier = Modifier
                    .size(110.dp)
                    .clip(CircleShape)
                    .background(VibrantRed.copy(alpha = 0.2f))
                    .border(3.dp, VibrantRed, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "💀",
                    fontSize = 54.sp
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            Text(
                text = "গেম শেষ! 😂",
                style = MaterialTheme.typography.headlineMedium.copy(
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 32.sp,
                    color = VibrantRed
                ),
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "তোমার ৩টি লাইফ শেষ হয়ে গেছে!",
                style = MaterialTheme.typography.bodyLarge.copy(
                    color = TextWhite,
                    fontSize = 16.sp
                ),
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(24.dp))

            // Score Summary Card (Glassmorphic)
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(28.dp),
                colors = CardDefaults.cardColors(containerColor = GlassWhite10),
                border = androidx.compose.foundation.BorderStroke(1.5.dp, GlassBorder)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(22.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "ফাইনাল স্কোর",
                        fontSize = 13.sp,
                        color = TextIndigoLight,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = "${gameState.score}",
                        fontSize = 46.sp,
                        fontWeight = FontWeight.Black,
                        color = VibrantYellow
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = GlassWhite20
                    ) {
                        Text(
                            text = "পৌঁছেছো লেভেল ${gameState.currentLevelIndex + 1}-এ (মোট $totalLevels)",
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                            color = TextWhite,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Text(
                        text = "“আরে ভাই, এত তাড়াতাড়ি হার মেনে নিলে? আরেকবার একটু বুদ্ধি খাটিয়ে দেখো!”",
                        fontSize = 14.sp,
                        color = VibrantYellow,
                        textAlign = TextAlign.Center,
                        lineHeight = 20.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(32.dp))

            // Buttons
            Button(
                onClick = onRestartGame,
                modifier = Modifier
                    .testTag("restart_game_button")
                    .fillMaxWidth()
                    .height(56.dp),
                shape = RoundedCornerShape(28.dp),
                colors = ButtonDefaults.buttonColors(containerColor = VibrantIndigo)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = null,
                        tint = Color.White
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "আবার খেলো 🔄",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            OutlinedButton(
                onClick = onGoToHome,
                modifier = Modifier
                    .testTag("home_screen_button")
                    .fillMaxWidth()
                    .height(52.dp),
                shape = RoundedCornerShape(26.dp),
                border = androidx.compose.foundation.BorderStroke(1.5.dp, GlassBorder)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Home,
                        contentDescription = null,
                        tint = TextIndigoLight
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "হোম স্ক্রিন 🏠",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextIndigoLight
                    )
                }
            }
        }
    }
}

