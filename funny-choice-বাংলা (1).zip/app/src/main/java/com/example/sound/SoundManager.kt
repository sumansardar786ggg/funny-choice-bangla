package com.example.sound

import android.content.Context
import android.media.AudioManager
import android.media.ToneGenerator
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class SoundManager(context: Context) {

    private var toneGenerator: ToneGenerator? = null
    private val scope = CoroutineScope(Dispatchers.Default)

    init {
        try {
            toneGenerator = ToneGenerator(AudioManager.STREAM_MUSIC, 80)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun playClickSound(enabled: Boolean) {
        if (!enabled) return
        scope.launch {
            try {
                toneGenerator?.startTone(ToneGenerator.TONE_PROP_BEEP, 80)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun playCorrectSound(enabled: Boolean) {
        if (!enabled) return
        scope.launch {
            try {
                toneGenerator?.startTone(ToneGenerator.TONE_DTMF_A, 100)
                delay(100)
                toneGenerator?.startTone(ToneGenerator.TONE_DTMF_B, 100)
                delay(100)
                toneGenerator?.startTone(ToneGenerator.TONE_PROP_ACK, 250)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun playWrongSound(enabled: Boolean) {
        if (!enabled) return
        scope.launch {
            try {
                toneGenerator?.startTone(ToneGenerator.TONE_PROP_NACK, 250)
                delay(120)
                toneGenerator?.startTone(ToneGenerator.TONE_CDMA_SOFT_ERROR_LITE, 200)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun playVictorySound(enabled: Boolean) {
        if (!enabled) return
        scope.launch {
            try {
                val tones = listOf(
                    ToneGenerator.TONE_DTMF_0 to 120L,
                    ToneGenerator.TONE_DTMF_3 to 120L,
                    ToneGenerator.TONE_DTMF_6 to 120L,
                    ToneGenerator.TONE_DTMF_9 to 300L
                )
                for ((tone, duration) in tones) {
                    toneGenerator?.startTone(tone, duration.toInt())
                    delay(duration)
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun release() {
        try {
            toneGenerator?.release()
            toneGenerator = null
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
