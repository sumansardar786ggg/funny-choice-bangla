package com.example.model

data class Question(
    val id: Int,
    val questionText: String,
    val options: List<String>,
    val correctOptionIndex: Int,
    val correctReactionText: String,
    val wrongReactionText: String
)

enum class ScreenState {
    HOME,
    GAME,
    GAME_OVER,
    WIN
}

data class GameState(
    val currentLevelIndex: Int = 0,
    val score: Int = 0,
    val lives: Int = 3,
    val selectedOptionIndex: Int? = null,
    val isAnswerChecked: Boolean = false,
    val isAnswerCorrect: Boolean = false,
    val currentReaction: String = "",
    val screenState: ScreenState = ScreenState.HOME,
    val isSoundEnabled: Boolean = true,
    val highScore: Int = 0
)
