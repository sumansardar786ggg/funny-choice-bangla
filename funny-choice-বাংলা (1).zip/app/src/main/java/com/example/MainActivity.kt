package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.model.ScreenState
import com.example.ui.screens.GameOverScreen
import com.example.ui.screens.GameScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.WinScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.GameViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                FunnyChoiceApp()
            }
        }
    }
}

@Composable
fun FunnyChoiceApp(
    viewModel: GameViewModel = viewModel()
) {
    val gameState by viewModel.gameState.collectAsStateWithLifecycle()

    Scaffold(
        modifier = Modifier.fillMaxSize()
    ) { innerPadding ->
        val contentModifier = Modifier.padding(innerPadding)

        when (gameState.screenState) {
            ScreenState.HOME -> {
                HomeScreen(
                    gameState = gameState,
                    onStartGame = { viewModel.startGame() },
                    onToggleSound = { viewModel.toggleSound() },
                    modifier = contentModifier
                )
            }
            ScreenState.GAME -> {
                GameScreen(
                    gameState = gameState,
                    currentQuestion = viewModel.currentQuestion,
                    totalLevels = viewModel.totalLevels,
                    onSelectOption = { viewModel.selectOption(it) },
                    onNextQuestion = { viewModel.nextQuestion() },
                    onToggleSound = { viewModel.toggleSound() },
                    modifier = contentModifier
                )
            }
            ScreenState.GAME_OVER -> {
                GameOverScreen(
                    gameState = gameState,
                    totalLevels = viewModel.totalLevels,
                    onRestartGame = { viewModel.startGame() },
                    onGoToHome = { viewModel.goToHome() },
                    modifier = contentModifier
                )
            }
            ScreenState.WIN -> {
                WinScreen(
                    gameState = gameState,
                    totalLevels = viewModel.totalLevels,
                    onRestartGame = { viewModel.startGame() },
                    onGoToHome = { viewModel.goToHome() },
                    modifier = contentModifier
                )
            }
        }
    }
}
