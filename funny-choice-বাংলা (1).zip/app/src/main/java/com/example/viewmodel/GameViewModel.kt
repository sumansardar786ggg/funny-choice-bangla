package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import com.example.data.QuestionsRepository
import com.example.model.GameState
import com.example.model.Question
import com.example.model.ScreenState
import com.example.sound.SoundManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

class GameViewModel(application: Application) : AndroidViewModel(application) {

    private val soundManager = SoundManager(application)
    private val _gameState = MutableStateFlow(GameState())
    val gameState: StateFlow<GameState> = _gameState.asStateFlow()

    val totalLevels: Int
        get() = QuestionsRepository.questions.size

    val currentQuestion: Question
        get() = QuestionsRepository.questions.getOrElse(_gameState.value.currentLevelIndex) {
            QuestionsRepository.questions.first()
        }

    fun startGame() {
        soundManager.playClickSound(_gameState.value.isSoundEnabled)
        _gameState.update {
            it.copy(
                currentLevelIndex = 0,
                score = 0,
                lives = 3,
                selectedOptionIndex = null,
                isAnswerChecked = false,
                isAnswerCorrect = false,
                currentReaction = "",
                screenState = ScreenState.GAME
            )
        }
    }

    fun selectOption(index: Int) {
        val state = _gameState.value
        if (state.isAnswerChecked) return

        val question = currentQuestion
        val isCorrect = index == question.correctOptionIndex
        val reaction = if (isCorrect) question.correctReactionText else question.wrongReactionText

        val newScore = if (isCorrect) state.score + 10 else state.score
        val newLives = if (isCorrect) state.lives else (state.lives - 1).coerceAtLeast(0)
        val newHighScore = maxOf(state.highScore, newScore)

        if (isCorrect) {
            soundManager.playCorrectSound(state.isSoundEnabled)
        } else {
            soundManager.playWrongSound(state.isSoundEnabled)
        }

        _gameState.update {
            it.copy(
                selectedOptionIndex = index,
                isAnswerChecked = true,
                isAnswerCorrect = isCorrect,
                score = newScore,
                lives = newLives,
                currentReaction = reaction,
                highScore = newHighScore
            )
        }
    }

    fun nextQuestion() {
        soundManager.playClickSound(_gameState.value.isSoundEnabled)
        val state = _gameState.value

        if (state.lives <= 0) {
            _gameState.update {
                it.copy(
                    screenState = ScreenState.GAME_OVER,
                    isAnswerChecked = false,
                    selectedOptionIndex = null
                )
            }
            return
        }

        val nextIndex = state.currentLevelIndex + 1
        if (nextIndex >= totalLevels) {
            soundManager.playVictorySound(state.isSoundEnabled)
            _gameState.update {
                it.copy(
                    screenState = ScreenState.WIN,
                    isAnswerChecked = false,
                    selectedOptionIndex = null
                )
            }
        } else {
            _gameState.update {
                it.copy(
                    currentLevelIndex = nextIndex,
                    selectedOptionIndex = null,
                    isAnswerChecked = false,
                    isAnswerCorrect = false,
                    currentReaction = ""
                )
            }
        }
    }

    fun toggleSound() {
        val newState = !_gameState.value.isSoundEnabled
        _gameState.update { it.copy(isSoundEnabled = newState) }
        soundManager.playClickSound(newState)
    }

    fun playClick() {
        soundManager.playClickSound(_gameState.value.isSoundEnabled)
    }

    fun goToHome() {
        soundManager.playClickSound(_gameState.value.isSoundEnabled)
        _gameState.update {
            it.copy(
                screenState = ScreenState.HOME,
                isAnswerChecked = false,
                selectedOptionIndex = null
            )
        }
    }

    override fun onCleared() {
        super.onCleared()
        soundManager.release()
    }
}
